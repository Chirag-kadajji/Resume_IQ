"""
Train a simple TF-IDF + Logistic Regression model that classifies resumes
into job roles. Run this ONCE before starting the Flask app:

    python train_model.py

It saves model/model.pkl and model/vectorizer.pkl
"""

import os
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

# ---------------------------------------------------------------------------
# Tiny built-in training dataset (replace / extend with your own resumes)
# Each row: (resume_text, label)
# ---------------------------------------------------------------------------
DATASET = [
    # Web Development
    ("Experienced frontend developer skilled in HTML, CSS, JavaScript, React and Node. Built responsive websites and SPAs. Familiar with REST APIs and Git.",
     "Web Development"),
    ("Web developer with strong HTML, CSS, JavaScript and React experience. Built e-commerce sites using Node and Express.",
     "Web Development"),
    ("Frontend engineer. React, Redux, JavaScript, HTML5, CSS3, Tailwind. Worked on dashboards and landing pages.",
     "Web Development"),
    ("Full stack web developer. HTML, CSS, JavaScript, React, Node, MongoDB. Deployed apps to AWS.",
     "Web Development"),

    # Data Science
    ("Data scientist with experience in Python, Pandas, NumPy, scikit-learn and machine learning. Built predictive models and dashboards.",
     "Data Science"),
    ("Machine learning engineer skilled in Python, TensorFlow, Pandas, NumPy and data science. Worked on NLP and recommendation systems.",
     "Data Science"),
    ("Data analyst turned data scientist. Python, SQL, Pandas, NumPy, machine learning, statistics, visualization with matplotlib.",
     "Data Science"),
    ("Applied scientist. Python, machine learning, deep learning, Pandas, NumPy. Published research on classification models.",
     "Data Science"),

    # Backend Developer
    ("Backend developer experienced in Java, Spring Boot, SQL and REST API design. Built scalable microservices.",
     "Backend Developer"),
    ("Server-side engineer. Java, SQL, API development, microservices, Docker, Kubernetes.",
     "Backend Developer"),
    ("Backend engineer. Java, Python, SQL databases, REST APIs, system design, performance tuning.",
     "Backend Developer"),
    ("Software engineer focused on backend systems. Java, SQL, API gateways, message queues, caching.",
     "Backend Developer"),

    # Python Developer (extra class so model has more variety)
    ("Python developer with Flask and Django experience. Built REST APIs, integrated SQL databases, deployed on Linux.",
     "Python Developer"),
    ("Software engineer specialized in Python, Flask, Django, SQL and automation scripts.",
     "Python Developer"),
    ("Python backend developer. Flask, Django REST framework, PostgreSQL, Redis, Celery.",
     "Python Developer"),
]


def main():
    texts = [row[0] for row in DATASET]
    labels = [row[1] for row in DATASET]

    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    X = vectorizer.fit_transform(texts)

    model = LogisticRegression(max_iter=1000)
    model.fit(X, labels)

    os.makedirs("model", exist_ok=True)
    with open(os.path.join("model", "model.pkl"), "wb") as f:
        pickle.dump(model, f)
    with open(os.path.join("model", "vectorizer.pkl"), "wb") as f:
        pickle.dump(vectorizer, f)

    print("Model trained and saved to model/model.pkl")
    print("Vectorizer saved to model/vectorizer.pkl")
    print("Classes:", list(model.classes_))


if __name__ == "__main__":
    main()
