import os
import pickle
import re
from flask import Flask, render_template, request, flash, redirect, url_for
from werkzeug.utils import secure_filename
import pdfplumber
from docx import Document

app = Flask(__name__)
app.secret_key = "resume-analyzer-secret-key"

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"pdf", "docx", "txt"}
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 5 * 1024 * 1024  # 5 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ---------------------------------------------------------------------------
# Load model + vectorizer (train_model.py must be run first)
# ---------------------------------------------------------------------------
MODEL_PATH = os.path.join("model", "model.pkl")
VECTORIZER_PATH = os.path.join("model", "vectorizer.pkl")

model = None
vectorizer = None
if os.path.exists(MODEL_PATH) and os.path.exists(VECTORIZER_PATH):
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)
    with open(VECTORIZER_PATH, "rb") as f:
        vectorizer = pickle.load(f)

# ---------------------------------------------------------------------------
# Skill database & role mapping
# ---------------------------------------------------------------------------
SKILLS = [
    "python", "java", "c++", "html", "css", "javascript",
    "react", "node", "sql", "machine learning", "data science",
    "flask", "django", "pandas", "numpy", "api",
]

ROLE_SKILLS = {
    "Web Development": ["html", "css", "javascript", "react", "node"],
    "Data Science": ["python", "machine learning", "pandas", "numpy"],
    "Backend Developer": ["java", "sql", "api"],
}

JOB_SUGGESTION_RULES = [
    (["machine learning", "data science", "pandas", "numpy"], "Data Scientist"),
    (["html", "css", "javascript", "react"], "Frontend Developer"),
    (["java", "sql", "api", "node"], "Backend Developer"),
    (["python", "flask", "django"], "Python Developer"),
]

WEAK_WORDS = ["responsible for", "worked on", "helped", "did", "made"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_text(filepath: str) -> str:
    ext = filepath.rsplit(".", 1)[1].lower()
    text = ""
    if ext == "pdf":
        with pdfplumber.open(filepath) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text() or ""
                text += page_text + "\n"
    elif ext == "docx":
        doc = Document(filepath)
        text = "\n".join(p.text for p in doc.paragraphs)
    elif ext == "txt":
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read()
    return text.strip()


def extract_skills(text: str):
    text_lower = text.lower()
    found = []
    for skill in SKILLS:
        # word boundary safe match (handles c++ too)
        pattern = r"(?<![a-z0-9])" + re.escape(skill) + r"(?![a-z0-9])"
        if re.search(pattern, text_lower):
            found.append(skill)
    return found


def calculate_ats(predicted_role: str, found_skills):
    required = ROLE_SKILLS.get(predicted_role, [])
    if not required:
        return 0, []
    matched = [s for s in required if s in found_skills]
    missing = [s for s in required if s not in found_skills]
    score = round((len(matched) / len(required)) * 100, 2)
    return score, missing


def suggest_jobs(found_skills):
    suggestions = []
    for required, role in JOB_SUGGESTION_RULES:
        if any(skill in found_skills for skill in required):
            if role not in suggestions:
                suggestions.append(role)
    return suggestions or ["Generalist Software Roles"]


def action_plan(missing_skills):
    plan = []
    if missing_skills:
        plan.append(f"Learn the following missing skills: {', '.join(missing_skills)}.")
    plan.append("Build 2-3 hands-on projects that showcase the missing skills.")
    plan.append("Push your projects to GitHub with clean README files.")
    plan.append("Contribute to open source to gain real-world experience.")
    plan.append("Tailor your resume keywords to each job description.")
    return plan


def resume_feedback(text: str, found_skills):
    feedback = []
    word_count = len(text.split())
    text_lower = text.lower()

    if len(found_skills) < 5:
        feedback.append("Add more relevant technical skills (you currently have fewer than 5).")
    if "project" not in text_lower:
        feedback.append("Add a 'Projects' section with measurable outcomes.")
    if "github" not in text_lower:
        feedback.append("Include a link to your GitHub profile.")
    if any(w in text_lower for w in WEAK_WORDS):
        feedback.append("Replace weak phrases (e.g. 'responsible for', 'worked on') with strong action verbs like 'built', 'led', 'optimized', 'shipped'.")
    if word_count < 200:
        feedback.append("Your resume seems too short — add more detail about achievements and impact.")
    if not feedback:
        feedback.append("Great resume! Keep it tailored to each application.")
    return feedback


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", result=None)


@app.route("/analyze", methods=["POST"])
def analyze():
    if model is None or vectorizer is None:
        flash("Model not found. Please run `python train_model.py` first.")
        return redirect(url_for("index"))

    if "resume" not in request.files:
        flash("No file uploaded.")
        return redirect(url_for("index"))

    file = request.files["resume"]
    if file.filename == "":
        flash("Please choose a file.")
        return redirect(url_for("index"))

    if not allowed_file(file.filename):
        flash("Unsupported file type. Use PDF, DOCX, or TXT.")
        return redirect(url_for("index"))

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    try:
        text = extract_text(filepath)
    except Exception as e:
        flash(f"Could not read file: {e}")
        return redirect(url_for("index"))

    if not text.strip():
        flash("The file appears to be empty.")
        return redirect(url_for("index"))

    # Predict
    vec = vectorizer.transform([text])
    predicted_role = model.predict(vec)[0]
    probabilities = model.predict_proba(vec)[0]
    match_score = round(max(probabilities) * 100, 2)

    found_skills = extract_skills(text)
    ats_score, missing_skills = calculate_ats(predicted_role, found_skills)
    jobs = suggest_jobs(found_skills)
    plan = action_plan(missing_skills)
    feedback = resume_feedback(text, found_skills)

    result = {
        "predicted_role": predicted_role,
        "match_score": match_score,
        "ats_score": ats_score,
        "skills": found_skills,
        "missing_skills": missing_skills,
        "jobs": jobs,
        "plan": plan,
        "feedback": feedback,
    }

    return render_template("index.html", result=result)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
