# AI Resume Analyzer

A Flask web app that uses TF-IDF + Logistic Regression to analyze resumes,
predict job roles, calculate ATS / match scores, find skill gaps and give
actionable feedback.

## Project Structure

```
resume-analyzer/
├── app.py                  # Flask backend
├── train_model.py          # Trains and saves the ML model
├── requirements.txt        # Python dependencies
├── templates/
│   └── index.html          # UI
├── static/
│   └── style.css           # Styling (gradient cards UI)
├── model/
│   ├── model.pkl           # Created after running train_model.py
│   └── vectorizer.pkl      # Created after running train_model.py
└── uploads/                # Uploaded resumes are saved here
```

## How to Run in VS Code (Windows / macOS / Linux)

1. **Install Python 3.10+** from https://www.python.org/downloads/
2. **Open the `resume-analyzer` folder in VS Code** (File → Open Folder).
3. **Open a terminal in VS Code** (`Ctrl+~`) and run:

   ```bash
   # Create a virtual environment
   python -m venv venv

   # Activate it
   # Windows:
   venv\Scripts\activate
   # macOS / Linux:
   source venv/bin/activate

   # Install dependencies
   pip install -r requirements.txt

   # Train the ML model (only needed once)
   python train_model.py

   # Start the web app
   python app.py
   ```

4. Open your browser at **http://localhost:5000** and upload a resume
   (PDF, DOCX, or TXT).

## Features

- Upload PDF / DOCX / TXT resumes
- TF-IDF + Logistic Regression role prediction
- Match score (model confidence %)
- ATS score based on role-specific required skills
- Skill extraction from a curated skill list
- Skill gap (missing skills for predicted role)
- Job recommendations based on skills
- Action plan & resume feedback (weak wording, missing GitHub, length, etc.)
- Modern gradient UI with cards, progress bars and skill tags

## Customization

- **Add more training data** in `train_model.py` (the `DATASET` list) and
  rerun `python train_model.py` to improve predictions.
- **Edit the `SKILLS` list** in `app.py` to recognize more technologies.
- **Edit `ROLE_SKILLS`** in `app.py` to tune ATS scoring per role.
